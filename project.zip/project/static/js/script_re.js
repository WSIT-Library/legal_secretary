let seconds = 0;  // 타이머 변수
const timerElement = document.getElementById('timer');  // 타이머 표시할 HTML 요소
let interval;

// 폼 제출 시 타이머 시작
document.getElementById('queryForm').onsubmit = function(event) {
    event.preventDefault();  // 폼 제출을 막고 타이머 시작

    // 로딩 메시지 표시
    document.getElementById('loadingMessage').style.display = 'block';

    // 타이머 시작
    interval = setInterval(function() {
        seconds++;  // 초 증가
        timerElement.innerText = seconds;  // 초 업데이트
    }, 1600);

    // 폼 제출 후, 서버에서 결과를 받아오기 위해 폼 전송
    setTimeout(function() {
        document.getElementById('queryForm').submit();
    }, 100);  // 타이머 시작 후 약간의 딜레이 후 폼 제출
};

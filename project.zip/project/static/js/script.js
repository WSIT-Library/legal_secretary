// script.js
// 폼 제출 이벤트 리스너
document.getElementById('queryForm').onsubmit = function() {
    // 로딩 메시지 보이기
    document.getElementById('loadingMessage').style.display = 'block';
    // 타이머 시작
    let seconds = 0;
    const timerElement = document.getElementById('timer');
    const interval = setInterval(function() {
        seconds++;
        timerElement.innerText = seconds; // 초 업데이트
    }, 1600);

    // 폼 제출 후 타이머 정리
    this.addEventListener('submit', function() {
        clearInterval(interval);
    });
};

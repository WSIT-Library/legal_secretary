# !pip install flask-ngrok
# !pip install langchain
# !pip install langchain_pinecone
# !pip install langchain[docarray]
# !pip install docarray
# !pip install pypdf
# !pip install langchain_community
# !pip install chromadb
# !pip install sentence-transformers
# !pip install PyMuPDF
# !pip install ngrok
# !pip install pyngrok
# !pip install gunicorn


# 커널에 설치되어있는 기본 패키지. 
# 10월26일 오후 9시~ 10월 27일 새벽 2시




#24/11/13 추가된 패키지.

# !pip install -U langchain-ollama
# !pip install -U langchain-chroma
# !pip install nest_asyncio
# !pip install flask 

#쥬피터, flask간 비동기 이벤트 충돌 방지
# nest_asyncio.apply()는 Python에서 Jupyter Notebook이나 IPython 같은 환경에서 이벤트 루프 충돌을 방지하기 위해 사용하는 코드입니다. asyncio 모듈은 Python의 비동기 작업을 처리하는 이벤트 루프를 사용하는데, Jupyter Notebook에서는 이미 실행 중인 이벤트 루프가 있습니다. 이 때문에 비동기 작업을 추가로 실행하려고 하면 충돌이 발생할 수 있습니다.
# nest_asyncio의 역할:
# nest_asyncio는 이 문제를 해결하기 위해 설치하고 호출하는 패키지로, 중첩된 이벤트 루프(nested event loops)를 지원하여 충돌 없이 새로운 비동기 작업을 실행할 수 있게 해줍니다.




from flask import Flask, render_template, request  # Flask 앱 생성과 HTML 렌더링 및 요청 처리를 위한 패키지
from pyngrok import ngrok  # 로컬 서버를 외부에서 접근 가능하게 해주는 ngrok 패키지
import os  # 파일 경로 및 시스템 관련 작업을 위한 os 모듈
import time  # 시간 지연을 처리하기 위한 time 모듈
import random # 랜덤 페이지 출력을 위한 random 모듈

# 필요한 패키지 임포트
from langchain_community.document_loaders import PyMuPDFLoader  # PDF 파일을 불러오기 위한 로더
from langchain.text_splitter import RecursiveCharacterTextSplitter  # 문서를 텍스트 조각으로 나누는 도구
# from langchain.embeddings import HuggingFaceEmbeddings  # 문서를 벡터로 변환하는 임베딩 도구
# from langchain.vectorstores import Chroma  # 벡터 데이터를 저장하고 검색하는 벡터 저장소
from langchain_community.chat_models import ChatOllama  # 한국어를 지원하는 LLaMA 모델
from langchain_core.runnables import RunnablePassthrough  # 질의를 그대로 전달하는 역할
from langchain_core.output_parsers import StrOutputParser  # 출력된 데이터를 파싱하여 처리하는 도구
from langchain_core.prompts import ChatPromptTemplate  # 프롬프트 템플릿을 설정하는 도구
# from langchain_chroma import Chroma
from langchain_chroma.vectorstores import Chroma
from langchain_ollama import ChatOllama
from langchain_huggingface import HuggingFaceEmbeddings


# RAG 구성 요소 설정

# RAG 구성요소를 설정하는 함수 정의 : setup_rag() 
def setup_rag(): 
    # PDF 데이터 파일 로드
    loader = PyMuPDFLoader("/home/user/Desktop/ML/pdf_data/testpdf.pdf")
    #절대경로 (Absolute Path) 사용하여 루트 디렉토리/부터 시작하여 정확한 위치 표기.
    pages = loader.load()
    # 사용 패키지: langchain_community.document_loaders
    #loader.load()는 pymuPDFLoader 객체에서 PDF문서를 읽고 해당 문서의 내용을 로드하는 기능을 수행.
    #PDF파일에서 텍스트를 추출하고, 해당텍스트를 후속처리 단계에서 사용할수 있는 형태로 반환하는 역할. 일종의 전처리 자동화 과정.
    #pdf문서의 내용은 일반적으로 텍스트와 이미지가 혼합되어 있는데 load() 메서드는 텍스트 추출에 중점을 둔 메서드임.
    #'PyMuPDFLoader'은 langchain_community.document_loaders에서 제공하는 클래스이며, pdf파일을 로드아혀 텍스트 및 메타데이터를 추출하는 기능을 제공함.
    #그중에서도 load() 메서드는 PDF파일을 읽고, 각 페이지의 텍스트를 추출하여 Document 객체 형식으로 반환함.
    #작동방식 1~3
    #1. pdf파일 열기 : PyMuPDFLoader는 PDF파일 경로를 인자로 받아 해당 파일을 연다.
    #2. 텍스트 추출: 각 페이지의 텍스트를 추출하고 , 페이지별로 나누어 데이터를 저장함. 이 텍스트는 나중에 처리하기위해
    #문서 분할(RecursiveCharaterTextsplitter)등의 작업을 할 수 있도록 준비됨.
    #3. 결과 반환: 추출한 페이지별 텍스트를 Document객체로 반환함. 이 객체는 나중에 문서 검색, 임베딩 생성, RAG 모델에 사용할수 있음.
    #사용이유
    #문서 전처리의 첫 단계. loader.load()는 이후에 RecursiveCharaterTextsplitter같은 텍스트 분할 도구가 사용할수 있도록 텍스트를 적절하게 구조화한후 나머지프로세스에 사용할수 있도록 넘겨주는 역할을함.



    # 문서 분리
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    #패키지 : langchain.text_splitter.RecursiveCharacterTextSplitter
    #RecursiveCharacterTextSplitter는 문서 내에서 500자씩 텍스트 문장을 청크로 나누고 100자씩 겹치는 방식으로 문서를 분할함.
    #긴 텍스트를 작은 청크로 나누는 역할을 함. 텍스트 분할은 텍스트처리의 핵심작업중 하나이며 대형언어 모델에서 효율적으로 검색할
    #수 있도록 입력으로 사용되는 크기를 조절하는 기능을함.
    #chunk_size 인자는 각 청크chunk의 최대크기를 정하는 인자
    #cunk_overlap은 각 청크간의 겹치는 부분의 크기를 설정. 이렇게 하면 텍스트 분할시 문맥이 잘려서 의미가 왜곡되는 문제를 줄일 수 있음.
    docs = text_splitter.split_documents(pages)
    #split_documents 메서드는 pages객체(pdf에서 추출한 텍스트가 들어있는 페이지 객체)를 입력으로 받아 각 페이지의 텍스트를 분할하여 
    #여러개의 텍스트 덩어리(청크)로 나누고 리스트 형식으로 반환하여 docs라는 이름을 지었음으로 docs 리스트가 반환됨.

    #사용 이유1~4
    #1. 대형 텍스트 처리: pdf 문서의 내용은 보통 매우 길고, 대형 언어 모델(GPT-3, GPT-4)은 한번에 처리할 수 있는 텍스트의 길이에 제한이 있음.
    #openai의 gpt-3는 한번에 약 4096개의 토큰을 처리할수 있다고하며 1개의 토큰은 보통 4~5개의 문자가 하나의 토큰임으로 영어기준 약 2000~3000단어에 해당됨.
    #따라서, 긴 문서를 한번에 처리하기에는 제한이 있기 때문에 문서 내용을 작은 덩어리(청크)로 분할하는 과정이 필요.

    #2. 문맥보존
    #chunk_overlap(겹치는 부분)을 사용함으로써, 텍스트가 나누어져도 문맥의 연속성을 어느정도 보완하고 보장하게 하여 데이터 결측치를 줄일수 있음.
    #이 방법은 트렌스포머(?)방식은 단어보다 문맥을 기반으로 분석함으로 더 정확한 결과가 나오도록 지원함.
    # 
    #3. 효율적인 검색
    # 텍스트가 너무 길면 검색시스템에서 계산이 복잡해져 효율적으로 검색하기 어려워짐.  따라서 문서를 작은 청크로 분할함으로써
    # 각 청크에서 점보검색을 각각 수행하고 관련 정보를 빠르게 찾을 수있음. 이 과정은 rag시스템에서 사용되는 주요 기능임.
    # split_documents로 분할된 문서들은 이후 백터화하여 chroma와 같은 백터 저장소에 저장되고, 이 벡터들로 더욱 빠르고 정확한 검색을 지원함.
    # 
    # 4. 데이터 전처리
    # 자연어처리(NLP)에서는 긴 문서를 처리할때 구체적인 데이터 전처리가 필요함. 긴 문서에서 의미단위로 나누어야 모델이 효율적으로 학습하거나 응답을 생성할 수 있음.
    # 이 텍스트 분할은 그러한 전처리를 인간이 하나씩 하는것보다 더욱 빠르고 방대하게 해주는것임.. 


    vectorstore = {} #?????

    # 벡터 저장소 생성
    vectorstore_path = 'vector_store'
    os.makedirs(vectorstore_path, exist_ok=True)
    # 임베딩 생성
    embeddings = HuggingFaceEmbeddings(model_name='BAAI/bge-m3', model_kwargs={'device': 'cpu'}, encode_kwargs={'normalize_embeddings': True})

    #벡터 저장소가 이미 존재하는지 확인
    if os.path.exists(vectorstore_path):
        #기존 벡터저장소 로드
        vectorstore = Chroma(persist_directory=vectorstore_path,embedding_function=embeddings)
        print("벡터저장소가 존재합니다.")

    else:
        # 임베딩 생성
        # embeddings = HuggingFaceEmbeddings(model_name='BAAI/bge-m3', model_kwargs={'device': 'cpu'}, encode_kwargs={'normalize_embeddings': True})
        #패키지: langchain.embeddings.HuggingFaceEmbeddings
        #huggingface에서 제공하는 모델을 사용하여 텍스트 임베딩을 생성함.
        #BAAI/bge-m3 모델을 사용하고 있으며, cuda 디바이스에서 실행되도록 설정하고 임베딩을 정규화함

        #임베딩이란.
        #고차원 텍스트 데이터를 저차원 벡터로 변환하는 방법임. 이 벡터는 텍스트의 의미를 수치적으로 표현하며 고차원 공간에서 유사한 의미를 가진 텍스트들이
        #가까운 위치에 배치되게함
        #normalize_embeddings는 임베딩을 정규화하는 매개변수.
        #벡터를 임베딩하거나 유사도를 계산할때 중요한것은 방향임. 실제로 문서의 의미를 벡터로 표현할때 벡터의 크기는 계산과정상 세기나 크기를 나타낼수
        #있지만 실제로 비교하고자 하는것은 의미의 유사성임으로 방향이 중요함.
        #그러므로 크기가 다르면 유사도 계산에서 크기차이에 의한 왜곡이 발생할 수 있기에 정규화하여 크기를 1로 맞추는것.
        #그리고 유사도 계산에서 일관성을 유지하기위해서이기도 한데 코사인유사도(cosine similarity)계산에서 정규화된 벡터를 사용하면
        #크기가 1인 벡터들간의 내적만 계산하면 되므로 유사도 계산이 간단해지고 일관정이 생김. 코사인 유사도의 경우 두 벡터가 완전히
        #같은 방향이면 유사도가 1, 정반대 방향이면 유사도가 -1, 수직방향이면 유사도가 0이됨.
        #즉 크기와는 무관하게 동일한 기준에서 벡터를 비교할 수있기때문에 비교가 더쉽고 간단하며 벡터의 방향유사성을 중심으로 작업을 할 수 있음.

        #baai모델은 beijing academy of artificial intelligence에서 개발한 언어모델임. 주로 고차원 임베딩공간에서의 텍스트 의미를 잡아내고 유사성을 계한하는데 사용됨.
        #특히 의미적 유사도 측정, 문서검색, 질의응답등에 특화된 모델
        #이 모델은 코사인유사도를 사용하며 벡터간의 유사성을 계산함. 코사인 유사도는 분모에 벡터의 크기가 들어감으로 내적 계산에서 유사도의 계산에 오차가 생길수 있음.
        #그러므로 벡터의 크기를 1에 근접하게 통일하여 방향성만 계산하도록 하는것.

        #baai/bge-m3 모델은 다국어 임베딩을 잘 처리할수 있게 학습된 모델로 주로 한국어와 중국어 임베딩에 사용됨.
        #이 모델은 단어간의 문맥을 학습하고 그 단어들간의 상호관계를 파악하여 텍스트의 의미적 구조를 이해함.

        #cuda란
        #nvidia가 개발한 병렬 컴퓨팅 플랫폼이자 프로그래밍 모델임. cuda는 nvidia의 gpu(graphics processing unit)을 활용하여 병렬 컴퓨팅 작업을 수행할 수 있게 해주는 기술임.


        # 벡터 저장소 생성 및 저장
        vectorstore = Chroma.from_documents(docs, embeddings, persist_directory=vectorstore_path)
        # 벡터스토어 데이터를 디스크에 저장
        vectorstore.persist()
        print("벡터저장소가 없습니다. 생성합니다.")



#
#
#
# ngrok 주소 변경부분. colab에서 엔드포인트 실행후 나온 url을 넣어줄것.
#
#
#
    # Ollama 모델 설정
    model = ChatOllama(model="benedict/linkbricks-llama3.1-korean:8b", temperature=0,
                       base_url="https://9936-34-142-151-71.ngrok-free.app"
                       #매번 colab에서 실행후 url 변경해줄것.   마지막에 / 슬라이스는 안넣는게 좋음.
                       )

    # 리트리버 설정
    retriever = vectorstore.as_retriever(search_kwargs={'k': 3})
    #다양성이 늘어날수 있어 실험하여 수치 산정하는것이 좋음.

    return retriever, model

# RAG 구성 요소 초기화
retriever, model = setup_rag()








# import nest_asyncio
# from werkzeug.serving import run_simple
# nest_asyncio.apply()


# Flask 앱 설정
app = Flask(__name__)
# app.debug = True

# 홈 페이지
@app.route('/')
def home():
    return render_template('index.html')

# 쿼리 처리 및 결과 출력
@app.route('/get_answer', methods=['POST'])
def get_answer():

    ############################################
    start_time = time.time()  # 요청 받기 전 시간

    query = request.form['query']  # 사용자가 입력한 쿼리 가져오기
    time.sleep(0.1)  # 응답 생성 안정화를 위해 잠시 대기

    ############################
    # Ollama 서버에 요청 보내기 전에
    send_time = time.time()  # Ollama로 요청 보내기 전 시간

    # 템플릿 파일의 상대 경로 설정
    # template_path = os.path.join("rag_temp", "template.txt")
    script_dir = os.path.dirname(os.path.abspath(__file__))  # 현재 스크립트 파일 위치
    template_path = os.path.join(script_dir, "rag_temp", "template.txt")

    # 템플릿 파일 읽기
    with open(template_path, 'r', encoding='utf-8') as file:
        template_content = file.read()

    # RAG 로직 수행
    prompt = ChatPromptTemplate.from_template(template_content)

    # RAG 체인 연결
    def format_docs(docs):
        return '\n\n'.join([d.page_content for d in docs])

    rag_chain = (
        {'context': retriever, 'question': RunnablePassthrough()}
        | prompt
        | model
        | StrOutputParser()
    )

    # Chain 실행
    answer = rag_chain.invoke(query)

    #######################################################
    response_time = time.time()  # Ollama로부터 응답을 받았을 때 시간
    print(f"Request received at: {start_time}, Sent to Ollama at: {send_time}, Response received at: {response_time}")

    return render_template('result.html', query=query, answer=answer)


# PDF 파일 경로
exam_path = "/home/user/Desktop/ML/pdf_data/exampdf.pdf"

# 변호사 시험 문제 랜덤 문제 페이지
@app.route('/random_exam')
def random_exam():
    # PDF 파일에서 랜덤 페이지의 텍스트 추출
    text = extract_text_from_pdf(exam_path)

    # 추출한 텍스트를 페이지에 전달
    return render_template('exam_page.html', exam_text=text)

# PyMuPDFLoader를 사용하여 랜덤 페이지의 텍스트만 추출하는 함수
def extract_text_from_pdf(exam_path):
    # PyMuPDFLoader로 PDF 로드
    loader = PyMuPDFLoader(exam_path)
    # PDF의 모든 페이지 로드
    documents = loader.load()

    # PDF의 페이지 수를 얻어 랜덤 페이지 번호 선택
    total_pages = len(documents)
    random_page_num = random.randint(0, total_pages - 1)  # 0부터 total_pages - 1까지 랜덤 숫자

    # 랜덤으로 선택된 페이지의 텍스트 추출
    page_text = documents[random_page_num].page_content  # 선택된 페이지의 텍스트

  
    return page_text






#실행.

######

if __name__ == "__main__":
    app.run() #   host='192.168.25.48',port=5000


    # uwsgi --ini /home/user/Desktop/ML/app.ini 
    # 터미널에서 실행.
    # 터미널에서 복사 붙여넣기는 ctrl+shift+c , ctrl + shift+v